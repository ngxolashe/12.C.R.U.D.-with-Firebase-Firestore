import { Component } from '@angular/core';
// import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-root',
  template: `<router-outlet></router-outlet>`
})
export class AppComponent {
  // constructor(private afs: AngularFirestore){
  //   console.log(afs);
  // }
}
