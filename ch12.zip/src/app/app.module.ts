import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { environment } from '../environments/environment'; 
import { AngularFireAnalyticsModule } from '@angular/fire/analytics';
import { UserComponent } from './user.component'
import {routing} from './app.routing'

import { ReactiveFormsModule } from '@angular/forms'; 
import { UserFormComponent } from './user-form.component';

@NgModule({
  declarations: [
    AppComponent, UserComponent, UserFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireAnalyticsModule,
    AngularFirestoreModule,
    ReactiveFormsModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
